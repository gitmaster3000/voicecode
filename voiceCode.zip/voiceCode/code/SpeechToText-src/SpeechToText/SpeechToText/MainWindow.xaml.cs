﻿#region using directives

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Speech.Recognition;
using System.Windows;
using System.Diagnostics;
using System.Windows.Forms;
using System.Windows.Shapes;




#endregion

namespace SpeechToText
{
    /// <summary>
    /// MainWindow class
    /// </summary>
    public partial class MainWindow : Window
    {
        static System.Drawing.Graphics graphics;
        #region locals
        int i = 0;
        int xVal = 1;
        int yVal = 200;
        ProcessStartInfo processStartInfo = null;
        Process process;
        /// <summary>
        /// the engine
        /// </summary>
        SpeechRecognitionEngine speechRecognitionEngine = null;

        /// <summary>
        /// list of predefined commands
        /// </summary>
        List<Word> words = new List<Word>();
        string[] grammar = new string[5] { "//statements.txt", "//variables.txt", "//operators.txt", "//numbers.txt", "//cond.txt" };
        //var,num,op,num,inc
        int[] seqFor = new int[4] { 1, 3, 2, 4 };
        //should be 1,2, 3 AND 1
        int[] seqIf = new int[3] { 1, 2, 3 };
        int[] seqInt = new int[3] { 1, 2, 3 };
        
        #endregion

        #region ctor

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow"/> class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            try
            {
                // create the engine
                speechRecognitionEngine = createSpeechEngine("en-US");

                // hook to events
                speechRecognitionEngine.AudioLevelUpdated += new EventHandler<AudioLevelUpdatedEventArgs>(engine_AudioLevelUpdated);
                speechRecognitionEngine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(engine_SpeechRecognized);

                // load dictionary
                loadGrammarAndCommands("//statements.txt");

                // use the system's default microphone
                speechRecognitionEngine.SetInputToDefaultAudioDevice();

                // start listening
                speechRecognitionEngine.RecognizeAsync(RecognizeMode.Multiple);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Voice recognition failed");
            }
        }

        #endregion

        #region internal functions and methods

        /// <summary>
        /// Creates the speech engine.
        /// </summary>
        /// <param name="preferredCulture">The preferred culture.</param>
        /// <returns></returns>
        private SpeechRecognitionEngine createSpeechEngine(string preferredCulture)
        {
            foreach (RecognizerInfo config in SpeechRecognitionEngine.InstalledRecognizers())
            {
                if (config.Culture.ToString() == preferredCulture)
                {
                    speechRecognitionEngine = new SpeechRecognitionEngine(config);
                    break;
                }
            }

            // if the desired culture is not found, then load default
            if (speechRecognitionEngine == null)
            {
                System.Windows.MessageBox.Show("The desired culture is not installed on this machine, the speech-engine will continue using "
                    + SpeechRecognitionEngine.InstalledRecognizers()[0].Culture.ToString() + " as the default culture.",
                    "Culture " + preferredCulture + " not found!");
                speechRecognitionEngine = new SpeechRecognitionEngine(SpeechRecognitionEngine.InstalledRecognizers()[0]);
            }

            return speechRecognitionEngine;
        }

        /// <summary>
        /// Loads the grammar and commands.
        /// </summary>
        private void loadGrammarAndCommands(string grammar)
        {
            try
            {
            //    Choices texts = new Choices();
            //    string[] lines = File.ReadAllLines(Environment.CurrentDirectory + grammar);
            //    foreach (string line in lines)
            //    {
            //        // skip commentblocks and empty lines..
            //        if (line.StartsWith("--") || line == String.Empty) continue;

            //        // split the line
            //        var parts = line.Split(new char[] { '|' });

            //        // add commandItem to the list for later lookup or execution
            //        words.Add(new Word() { Text = parts[0], AttachedText = parts[1], IsShellCommand = (parts[2] == "true") });

            //        // add the text to the known choices of speechengine
            //        texts.Add(parts[0]);
            //    }
            //    Grammar wordsList = new Grammar(new GrammarBuilder(texts));
            //    speechRecognitionEngine.UnloadAllGrammars();

                speechRecognitionEngine.LoadGrammar(CreateGrammarFromFile());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static Grammar CreateGrammarFromFile()
        { //GRAMMAR
            Grammar citiesGrammar = new Grammar("sol_1.xml");
            citiesGrammar.Name = "SRGS File Solitaire Grammar";
            return citiesGrammar;
        }


        /// <summary>
        /// Gets the known command.
        /// </summary>
        /// <param name="command">The order.</param>
        /// <returns></returns>
        private string getKnownTextOrExecute(string command)
        {
            try
            {
                var cmd = words.Where(c => c.Text == command).First();

                if (cmd.IsShellCommand)
                {
                    Process proc = new Process();
                    proc.EnableRaisingEvents = false;
                    proc.StartInfo.FileName = cmd.AttachedText;
                    proc.Start();
                    return "you just started : " + cmd.AttachedText;
                }
                else
                {

                    return cmd.AttachedText;
                }
            }
            catch (Exception)
            {


                return command;
            }
        }

        #endregion

        #region speechEngine events

        /// <summary>
        /// Handles the SpeechRecognized event of the engine control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Speech.Recognition.SpeechRecognizedEventArgs"/> instance containing the event data.</param>
        void engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {

            String output = getKnownTextOrExecute(e.Result.Semantics["final"].Value.ToString());

            ///////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////
            //End array closes the array
            if (output == "End Array")
            {
                output = "}; \n";
                SendKeys.SendWait("\b");
            }
            else if (output == "#include")
            {
                output += " <";
            }
            if (output == "Save")
            {
                System.IO.File.WriteAllText(@"C:\VoiceCode\CPPFILE.cpp", txtSpoken.Text);
                System.Windows.MessageBox.Show(this, "Your code has been saved successfully!");

              
            }
            else if (output == "Compile")
            {

                 processStartInfo = new ProcessStartInfo(@"C:\windows\System32\cmd.exe");
                processStartInfo.RedirectStandardInput = true;
                processStartInfo.RedirectStandardOutput = false;
                processStartInfo.UseShellExecute = false;

                process = Process.Start(processStartInfo);

                if (process != null)
                {
                    System.Windows.MessageBox.Show(this, "Program compiled, please view the cmd window for details!");
                    process.StandardInput.WriteLine("cd C:\\VoiceCode");

                    process.StandardInput.WriteLine("G++ CPPFILE.CPP -o output");


                    
                }



            }

            else if (output == "execute") {


                if (process != null)
                {
                    System.Windows.MessageBox.Show(this, "Execution successfull, view output in the cmd window!");
                    
                    process.StandardInput.WriteLine("cls");
                    process.StandardInput.WriteLine("output");
                   
                }


                else
                {

                       // are complete
                   System.Windows.MessageBox.Show(this,"Please compile your program first!");

                }
                //try
                //{
                //    processStartInfo = new ProcessStartInfo(@"C:\VoiceCode\output.exe");
                //}
                //catch (Exception)
                //{
                    
                //    throw;
                //}
                //processStartInfo.RedirectStandardInput = true;
                //processStartInfo.RedirectStandardOutput = true;
                //processStartInfo.UseShellExecute = false;

                //Process p = new Process();
                
                //psi.FileName = "CMD.EXE";
                //psi.Arguments = "/K yourmainprocess.exe";
                //p.Start(psi);
                //p.WaitForExit();

            
            }

            else
            {



                ////OUTPUT
                if (e.Result.Text == "start")
                {
                    if (txtSpoken.Text[txtSpoken.Text.Length - 1] == ';')
                    {
                        SendKeys.SendWait("{BACKSPACE}");
                    }
                }


                if (output == "undo")
                {
                    output = "";
                    SendKeys.SendWait("^(z)");
                }

                else if (output == "redo")
                {
                    output = "";
                    SendKeys.SendWait("^(y)");
                }


                else
                {
                    txtSpoken.Text += " " + output;

                }


                //BRING CURSOR TO END
                txtSpoken.Focus();
                txtSpoken.SelectionStart = txtSpoken.Text.Length;

            }

                txtSpoken1.Text = "\r word is: " + getKnownTextOrExecute(e.Result.Text) + "\r alternate is: \r ";
                i++;




            

            //alternates
            foreach (RecognizedPhrase phrase in e.Result.Alternates)
            {

                txtSpoken1.Text += e.Result.Confidence + getKnownTextOrExecute(phrase.Text) + " ,";

            }


        }

        /// <summary>
        /// Handles the AudioLevelUpdated event of the engine control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Speech.Recognition.AudioLevelUpdatedEventArgs"/> instance containing the event data.</param>
        /// ///////////////////////////////////////////////////////////////////////////////////////////
        /// /////////////////////////////////////////////////////////////////////////////////////////
        void engine_AudioLevelUpdated(object sender, AudioLevelUpdatedEventArgs e)
        {
            Line line = new Line();
            line.Stroke = System.Windows.Media.Brushes.Blue;
            line.X1 = xVal;
            line.Y1 = 183;

            line.X2 = xVal;
            line.Y2 = 183 - (e.AudioLevel * 1.5);
            xVal++;
            line.StrokeThickness = 1;
            myCanvas.Children.Add(line);
            if (xVal == 700)
            {
                xVal = 1;
                myCanvas.Children.Clear();
            }
        }

        #endregion

        #region window closing

        /// <summary>
        /// Handles the Closing event of the Window control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.CancelEventArgs"/> instance containing the event data.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // unhook events
            speechRecognitionEngine.RecognizeAsyncStop();
            // clean references
            speechRecognitionEngine.Dispose();
        }

        #endregion

        #region GUI events

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }




        #endregion

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void prgLevel_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }

       
    }
}
