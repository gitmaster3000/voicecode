﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace VoiceCodeSplashScreen
{
    public partial class SplashScreen : Form
    {
        Timer timer;
        public SplashScreen()
        {
            InitializeComponent();
        }

        private void SplashScreen_Shown(object sender, EventArgs e)
        {
            timer = new Timer();

            timer.Interval = 3000;
            timer.Start();
            timer.Tick += ticks;
        }

        void ticks(object sender, EventArgs e)
        {
            timer.Stop();
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
