﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using SpeechLib;

using System.Diagnostics;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        SpSharedRecoContext ssrc;
         
        //[DllImport("User32.dll")]
        //public static extern int SetForegroundWindow(IntPtr point);

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //static extern IntPtr FindWindow(string lpClass, string lpW);

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
        //[return: MarshalAs(UnmanagedType.Bool)]
        //[DllImport("user32.dll", SetLastError = true)]
        //public static extern void PostMessage(IntPtr hWnd, int msg, int wParam, int lParam);


        public Form1()
        {
           InitializeComponent();
           ssrc = new SpSharedRecoContext();

          //  ispSpeechReco.DisplayUI(this.Handle.ToInt32(), "Hello", "AddRemoveWord", "abcd");
           // Process proc = new Process();
///string exePath = @"C:\sh2.lnk";
         ////   var psi = new ProcessStartInfo();
        //    psi.FileName = exePath;
            //psi.WorkingDirectory = Path.GetDirectoryName(exePath);
           // psi.Arguments = @"C:\Windows\System32\Speech\SpeechUX\SpeechUXWiz.exe AddRemoveWord";
       
          //  Process.Start(psi);
            
            //proc.Start();
      ////  SendMessage(handle, WM_COMMAND,  IntPtr.Zero, (IntPtr)3);
      //   // PostMessage(handle, WM_COMMAND, 3, 0);
      //   // SendKeys.Send("{MENU}");
      //      SendKeys.SendWait("+{F10}");


         //  Process p1 = Process.Start("notepad.exe");
         //  
         //Process  p = Process.GetProcessesByName("Speech Recognition").FirstOrDefault();
           
         //       IntPtr h = p.MainWindowHandle;
         //       SetForegroundWindow(h);

         //       SendKeys.SendWait("+{F10}");
         //       Thread.Sleep(200);
         //    //   PostMessage(h, WM_COMMAND, 2, 0);
            //   SendMessage(Window, WM_COMMAND, (IntPtr)2, (IntPtr)0);

            

          
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

         
            ISpeechRecognizer ispSpeechReco = ssrc.Recognizer;
            // ispSpeechReco.DisplayUI(this.Handle.ToInt32(), "Additional Pronunciation", "VocabularyManager", "example");
            if (ispSpeechReco.IsUISupported("AddRemoveWord", null))
            {
                ispSpeechReco.DisplayUI(this.Handle.ToInt32(), "Additional Training", "AddRemoveWord", "");
            }


        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\VoiceCode\SpeechToText.exe");
        }

        
    }
}


