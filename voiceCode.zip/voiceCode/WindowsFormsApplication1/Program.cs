﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Text;
using System.Diagnostics;
using System.Windows;
using System.Threading;
using System.Runtime.InteropServices;
using VoiceCodeSplashScreen;
namespace WindowsFormsApplication1
{
    static class Program
    {
        [DllImport("User32.dll", EntryPoint = "PostMessageA", SetLastError = true)]
        public static extern int SetForegroundWindow(IntPtr point);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr FindWindow(string lpClass, string lpW);

        [DllImport("user32.dll", CharSet= CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError=true)]
        public static extern void PostMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new SplashScreen());
            

             
            
            
        }

     
    }
}






